import { useEffect, useMemo, useState } from "react";

type Tab = "live" | "repo" | "readme";
type LiveTab = "landing" | "signup" | "dashboard";

const SOLIDITY_CODE = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title AjoChain - Decentralized Esusu on Base Sepolia
/// @notice No chairman. Code holds the money, auto-rotates payouts.
contract AjoChain {
    struct Pool {
        uint256 id;
        address creator;
        uint256 amount; // per contribution e.g 100k wei equiv
        uint256 target; // total per cycle
        uint8 membersNeeded;
        uint8 membersJoined;
        uint8 contributionsThisCycle;
        uint8 currentRound;
        uint256 cycleId;
        uint256 balance;
        uint256 createdAt;
        uint256 nextPayoutAt;
        bool active;
        address[] members;
        mapping(address => bool) isMember;
        mapping(address => uint256) lastPaidCycle;
        mapping(address => uint256) totalPaid;
    }

    uint256 public nextPoolId = 12;
    mapping(uint256 => Pool) private pools;
    mapping(address => uint256[]) public userPools;

    event PoolCreated(uint256 indexed poolId, address indexed creator, uint256 amount, uint8 members);
    event Contributed(uint256 indexed poolId, address indexed member, uint256 cycleId, uint256 amount);
    event Payout(uint256 indexed poolId, address indexed winner, uint256 amount, uint256 cycleId);
    event PoolCompleted(uint256 indexed poolId);

    modifier onlyMember(uint256 _poolId) {
        require(pools[_poolId].isMember[msg.sender], "Not member");
        _;
    }

    function createPool(uint256 _amountPerContrib, uint8 _membersNeeded, uint256 _cycleDuration) external returns (uint256) {
        require(_membersNeeded >= 2 && _membersNeeded <= 12, "2-12 members");
        require(_amountPerContrib > 0, "amount>0");
        uint256 pid = nextPoolId++;
        Pool storage p = pools[pid];
        p.id = pid;
        p.creator = msg.sender;
        p.amount = _amountPerContrib;
        p.target = _amountPerContrib * _membersNeeded;
        p.membersNeeded = _membersNeeded;
        p.membersJoined = 1;
        p.currentRound = 0;
        p.cycleId = 1;
        p.createdAt = block.timestamp;
        p.nextPayoutAt = block.timestamp + _cycleDuration;
        p.active = true;
        p.members.push(msg.sender);
        p.isMember[msg.sender] = true;
        userPools[msg.sender].push(pid);
        emit PoolCreated(pid, msg.sender, _amountPerContrib, _membersNeeded);
        return pid;
    }

    function joinPool(uint256 _poolId) external {
        Pool storage p = pools[_poolId];
        require(p.active, "inactive");
        require(!p.isMember[msg.sender], "already");
        require(p.membersJoined < p.membersNeeded, "full");
        p.members.push(msg.sender);
        p.isMember[msg.sender] = true;
        p.membersJoined++;
        userPools[msg.sender].push(_poolId);
    }

    function contribute(uint256 _poolId) external payable onlyMember(_poolId) {
        Pool storage p = pools[_poolId];
        require(p.active, "inactive");
        require(msg.value == p.amount, "exact amount");
        require(p.lastPaidCycle[msg.sender] < p.cycleId, "already paid");
        p.lastPaidCycle[msg.sender] = p.cycleId;
        p.totalPaid[msg.sender] += msg.value;
        p.balance += msg.value;
        p.contributionsThisCycle++;

        emit Contributed(_poolId, msg.sender, p.cycleId, msg.value);

        if (p.contributionsThisCycle == p.membersNeeded) {
            _payout(_poolId);
        }
    }

    function _payout(uint256 _poolId) internal {
        Pool storage p = pools[_poolId];
        address winner = p.members[p.currentRound % p.membersNeeded];
        uint256 prize = p.balance;
        p.balance = 0;
        p.contributionsThisCycle = 0;
        p.cycleId++;
        p.currentRound++;
        p.nextPayoutAt = block.timestamp + 12 days; // next cycle mock

        (bool ok, ) = winner.call{value: prize}("");
        require(ok, "payout failed");
        emit Payout(_poolId, winner, prize, p.cycleId - 1);

        if (p.currentRound >= p.membersNeeded) {
            p.active = false;
            emit PoolCompleted(_poolId);
        }
    }

    function getPool(uint256 _poolId) external view returns (
        uint256 id, address creator, uint256 amount, uint8 needed, uint8 joined, uint256 balance, bool active
    ) {
        Pool storage p = pools[_poolId];
        return (p.id, p.creator, p.amount, p.membersNeeded, p.membersJoined, p.balance, p.active);
    }

    receive() external payable {}
}
`;

const repoFiles = [
  { name: "index.html", lang: "html", content: "<!doctype html><html><body><div id=root> AjoChain Live </div></body></html>" },
  { name: "contracts/AjoChain.sol", lang: "solidity", content: SOLIDITY_CODE },
  { name: "app/page.tsx", lang: "tsx", content: `"use client"\nimport KoloLogo from '@/components/KoloLogo'\nexport default function Page(){ return <main><KoloLogo/><h1>The bank is the code.</h1></main> }` },
  { name: "components/KoloLogo.tsx", lang: "tsx", content: `export default function KoloLogo(){ return (<svg viewBox="0 0 64 64"> ...magenta->yellow gradient chain </svg>) }` },
  { name: "lib/wagmi.ts", lang: "ts", content: `import { http, createConfig } from 'wagmi'\nimport { baseSepolia } from 'wagmi/chains'\nexport const config = createConfig({ chains:[baseSepolia], transports:{[baseSepolia.id]: http()} })` },
  { name: "vercel.json", lang: "json", content: `{\n  "framework": "nextjs",\n  "regions": ["fra1"],\n  "buildCommand": "npm run build"\n}` },
  { name: "README.md", lang: "md", content: "# AjoChain\nDecentralized Esusu. No chairman.\n" },
  { name: "package.json", lang: "json", content: `{\n  "name":"ajochain",\n  "scripts":{"dev":"next dev","build":"next build"}\n}` },
];

function KoloLogoSVG({ size = 40 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Kolo pot logo">
      <defs>
        <linearGradient id="koloGrad" x1="8" y1="8" x2="56" y2="56" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FF006A" />
          <stop offset="0.55" stopColor="#FF4D8E" />
          <stop offset="1" stopColor="#FFD60A" />
        </linearGradient>
        <linearGradient id="chainGrad" x1="12" y1="12" x2="52" y2="28" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FFD60A" />
          <stop offset="1" stopColor="#FFB700" />
        </linearGradient>
        <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="3" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>
      {/* pot body */}
      <path d="M12 28 C12 20 18 12 32 12 C46 12 52 20 52 28 L52 32 C52 44 44 54 32 54 C20 54 12 44 12 32 Z" fill="url(#koloGrad)" />
      <path d="M14 29 Q32 38 50 29" stroke="white" strokeOpacity="0.75" strokeWidth="2.2" strokeLinecap="round" />
      <path d="M16 35 Q32 44 48 35" stroke="white" strokeOpacity="0.45" strokeWidth="1.8" strokeLinecap="round" />
      {/* rim */}
      <ellipse cx="32" cy="28" rx="20" ry="7.5" fill="#1A1326" fillOpacity="0.92" />
      <ellipse cx="32" cy="26.5" rx="18" ry="6" fill="url(#koloGrad)" />
      <ellipse cx="32" cy="26.5" rx="10" ry="3.2" fill="#0F0A14" fillOpacity="0.9" />
      {/* gold chain around */}
      <g stroke="url(#chainGrad)" strokeWidth="3" strokeLinecap="round" fill="none" filter="url(#glow)">
        <path d="M8 22 Q10 18 14 20 T22 20 T30 21" />
        <path d="M34 21 T42 20 T50 20 T56 23" />
        <circle cx="14" cy="20" r="3.2" fill="#FFD60A" stroke="#FFA600" />
        <circle cx="22" cy="20" r="3.2" fill="#FFD60A" stroke="#FFA600" />
        <circle cx="30" cy="21" r="3.2" fill="#FFD60A" stroke="#FFA600" />
        <circle cx="38" cy="21" r="3.2" fill="#FFD60A" stroke="#FFA600" />
        <circle cx="46" cy="20" r="3.2" fill="#FFD60A" stroke="#FFA600" />
        <circle cx="54" cy="21.5" r="3.2" fill="#FFD60A" stroke="#FFA600" />
      </g>
      {/* little coin */}
      <circle cx="32" cy="47" r="4.5" fill="#FFD60A" stroke="#1A1326" strokeWidth="1" />
      <text x="32" y="48.8" textAnchor="middle" fontSize="6" fontWeight="800" fill="#1A1326">₦</text>
    </svg>
  );
}

export default function App() {
  const [tab, setTab] = useState<Tab>("live");
  const [liveTab, setLiveTab] = useState<LiveTab>("landing");
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [wallet, setWallet] = useState<string | null>(null);
  const [chip, setChip] = useState<string>("₦100k");
  const [paid, setPaid] = useState(false);
  const [repoFile, setRepoFile] = useState(repoFiles[1].name);
  const [countdown, setCountdown] = useState({ d: 12, h: 4, m: 22, s: 18 });

  const activeRepo = useMemo(() => repoFiles.find(f => f.name === repoFile)!, [repoFile]);

  useEffect(() => {
    const t = setInterval(() => {
      setCountdown(c => {
        let { d, h, m, s } = c;
        s -= 1;
        if (s < 0) { s = 59; m -= 1; }
        if (m < 0) { m = 59; h -= 1; }
        if (h < 0) { h = 23; d -= 1; }
        if (d < 0) { d = 12; h = 4; m = 22; s = 18; }
        return { d, h, m, s };
      });
    }, 1000);
    return () => clearInterval(t);
  }, []);

  const toggleTheme = () => setTheme(t => (t === "light" ? "dark" : "light"));

  return (
    <div
      data-safe-area-inset-root
      className="min-h-screen w-full overflow-x-clip"
      style={{
        boxSizing: "border-box",
        paddingTop: "var(--safe-area-inset-top)",
        background: theme === "dark" ? "var(--bg)" : "var(--bg)",
        color: "var(--fg)",
      }}
      data-theme={theme}
    >
      <style>{`
        [data-theme="dark"]{ --bg:#0F0A14; --bg-2:#1A1326; --fg:#FFFEFB; --muted:#A99EC2; --line:#2A2140; --card:#1E172F; --card-2:#241E36; }
        [data-theme="light"]{ --bg:#FFF8F0; --bg-2:#FFFFFF; --fg:#16121F; --muted:#6B6580; --line:#EEE5DA; --card:#FFFFFF; --card-2:#FFF2E3; }
      `}</style>

      {/* HEADER */}
      <header
        data-safe-area-sticky-top
        className="sticky z-30 backdrop-blur-xl border-b"
        style={{
          top: "calc(var(--safe-area-inset-top) + 0px)",
          background: theme === "dark" ? "rgba(15,10,20,0.82)" : "rgba(255,248,240,0.82)",
          borderColor: "var(--line)",
        }}
      >
        <div className="mx-auto max-w-[1080px] px-4 sm:px-6 h-[64px] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <KoloLogoSVG size={42} />
            <div className="leading-none">
              <div className="flex items-baseline gap-2">
                <span className="text-[20px] font-[800] tracking-[-0.02em]">AjoChain</span>
                <span className="hidden sm:inline text-[10px] mono px-2 py-1 rounded-full border" style={{ borderColor: "var(--line)", background: "var(--card-2)", color: "var(--muted)" }}>
                  Base Sepolia • SELF-CONTAINED
                </span>
              </div>
              <div className="text-[11px] mono font-semibold tracking-wide mt-[2px]" style={{ color: "var(--muted)" }}>
                The bank is the code.
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden md:flex items-center gap-2 mr-2 text-[11px] mono" style={{ color: "var(--muted)" }}>
              <span>Decentralized Esusu. No chairman. Code holds the money, auto-rotates payouts. Base Sepolia.</span>
              <span className="w-1 h-1 rounded-full bg-[var(--mag)] inline-block" />
              <span>Wallet = ID, no phone, no KYC</span>
            </div>
            <button
              onClick={toggleTheme}
              className="h-9 px-3 rounded-full border text-[12px] font-bold mono flex items-center gap-2"
              style={{ borderColor: "var(--line)", background: "var(--card)" }}
            >
              <span className="w-3 h-3 rounded-full" style={{ background: theme === "dark" ? "#FFD60A" : "#FF006A" }} />
              {theme === "dark" ? "LIGHT" : "DARK"}
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="mx-auto max-w-[1080px] px-4 sm:px-6 pb-3 flex items-center gap-2">
          {[
            { k: "live", label: "LIVE APP", sub: "pool → pay → payout" },
            { k: "repo", label: "REPO", sub: "8 files" },
            { k: "readme", label: "README", sub: "docs" },
          ].map(t => (
            <button
              key={t.k}
              onClick={() => setTab(t.k as Tab)}
              className={`relative h-[44px] px-4 rounded-full border text-[13px] font-[800] tracking-[-0.01em] transition-all flex items-center gap-2 ${tab === t.k ? "text-white" : ""}`}
              style={{
                background: tab === t.k ? "linear-gradient(135deg,#FF006A 0%,#FF7A00 50%,#FFD60A 100%)" : "var(--card)",
                borderColor: tab === t.k ? "transparent" : "var(--line)",
                color: tab === t.k ? "white" : "var(--fg)",
                boxShadow: tab === t.k ? "0 12px 30px -10px rgba(255,0,106,0.6)" : "none",
              }}
            >
              {t.label}
              <span className={`hidden sm:inline text-[10px] mono px-2 py-0.5 rounded-full ${tab === t.k ? "bg-black/15 text-white" : "bg-[var(--card-2)] text-[var(--muted)]"}`}>{t.sub}</span>
            </button>
          ))}
          <div className="ml-auto hidden sm:flex items-center gap-2">
            <div className="h-7 px-3 rounded-full mono text-[10px] flex items-center gap-1.5 border" style={{ borderColor: "var(--line)", background: "var(--card)" }}>
              <span className="w-2 h-2 rounded-full bg-[#00E676] animate-pulse" /> fra1::2btdr-179... NO 404
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1080px] px-4 sm:px-6 pt-6 pb-[96px] sm:pb-10">
        {/* mobile description */}
        <div className="md:hidden mb-4 p-3 rounded-2xl border text-[11px] mono leading-relaxed" style={{ borderColor: "var(--line)", background: "var(--card)", color: "var(--muted)" }}>
          Decentralized Esusu. No chairman. Code holds the money, auto-rotates payouts. Base Sepolia. <span className="text-[var(--fg)] font-bold">Wallet = ID, no phone, no KYC</span>
        </div>

        {tab === "live" && (
          <div>
            {liveTab === "landing" && (
              <section className="grid md:grid-cols-[1.15fr_0.85fr] gap-5">
                {/* Hero */}
                <div className="rounded-[32px] border p-6 sm:p-8 overflow-hidden relative" style={{ background: "var(--card)", borderColor: "var(--line)", boxShadow: "var(--shadow)" }}>
                  <div className="absolute -right-20 -top-20 w-[320px] h-[320px] rounded-full blur-[50px] opacity-30" style={{ background: "radial-gradient(circle at 30% 30%, #FF006A, #FFD60A)" }} />
                  <div className="relative">
                    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-[11px] mono font-bold" style={{ borderColor: "var(--line)", background: "var(--card-2)" }}>
                      <span className="w-2 h-2 rounded-full bg-[#FF006A]" /> LIVE ON BASE SEPOLIA • NO CHAIRMAN
                    </div>
                    <h1 className="mt-5 text-[48px] sm:text-[64px] font-[800] leading-[0.88] tracking-[-0.04em]">
                      The bank <br />
                      <span style={{ background: "linear-gradient(90deg,#FF006A,#FFD60A)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>is the code.</span>
                    </h1>
                    <p className="mt-4 text-[16px] leading-6 max-w-[44ch]" style={{ color: "var(--muted)" }}>
                      Esusu without trust issues. Pool funds are locked in contract, auto-rotates to next member every cycle. No WhatsApp admin, no stories.
                    </p>

                    <div className="mt-8 grid grid-cols-3 gap-3">
                      <div className="rounded-2xl border p-3" style={{ borderColor: "var(--line)", background: "var(--card-2)" }}>
                        <div className="text-[11px] mono" style={{ color: "var(--muted)" }}>TVL LOCKED</div>
                        <div className="text-[22px] font-[800]">₦12.4M+</div>
                        <div className="mt-2 h-2 rounded-full overflow-hidden" style={{ background: "var(--line)" }}>
                          <div className="h-full w-[87%]" style={{ background: "linear-gradient(90deg,#FF006A,#FFD60A)" }} />
                        </div>
                        <div className="mt-1 text-[10px] mono">87% utilization</div>
                      </div>
                      <div className="rounded-2xl border p-3" style={{ borderColor: "var(--line)", background: "var(--card-2)" }}>
                        <div className="text-[11px] mono" style={{ color: "var(--muted)" }}>POOLS</div>
                        <div className="text-[22px] font-[800]">1,240</div>
                        <div className="mt-2 text-[10px] mono leading-tight">Active on Base Sepolia testnet</div>
                      </div>
                      <div className="rounded-2xl border p-3" style={{ borderColor: "var(--line)", background: "var(--card-2)" }}>
                        <div className="text-[11px] mono" style={{ color: "var(--muted)" }}>NO MAP DOTS</div>
                        <div className="text-[14px] font-[700] leading-tight mt-1">We removed fake geography. Just code & people.</div>
                      </div>
                    </div>

                    <div className="mt-8 flex flex-wrap gap-3">
                      <button
                        onClick={() => setLiveTab("signup")}
                        className="h-12 px-6 rounded-full text-white font-[800] tracking-[-0.01em] text-[14px] shadow-lg"
                        style={{ background: "linear-gradient(135deg,#FF006A,#FF7A00)" }}
                      >
                        Start Pool →
                      </button>
                      <button
                        onClick={() => setLiveTab("dashboard")}
                        className="h-12 px-6 rounded-full border font-[800] text-[14px]"
                        style={{ borderColor: "var(--line)", background: "var(--bg-2)" }}
                      >
                        View Demo Pool #12
                      </button>
                    </div>

                    <div className="mt-6 flex items-center gap-2 text-[11px] mono" style={{ color: "var(--muted)" }}>
                      <span className="w-2 h-2 rounded-full bg-[#C6FF00] border border-black/10" />
                      Self-contained • No 404 • Single HTML artifact
                    </div>
                  </div>
                </div>

                {/* side stack */}
                <div className="grid gap-5">
                  <div className="rounded-[28px] border p-5" style={{ borderColor: "var(--line)", background: "linear-gradient(180deg, var(--card) 0%, var(--card-2) 100%)" }}>
                    <div className="text-[12px] mono font-bold flex items-center justify-between">
                      <span>HOW IT SLAPS</span>
                      <span className="px-2 py-1 rounded-full bg-[var(--fg)] text-[var(--bg)] text-[10px]">GEN Z</span>
                    </div>
                    <div className="mt-4 grid gap-3">
                      {[
                        { n: "01", t: "Create Kolo", d: "Pick ₦50k-₦500k, 3-12 members" },
                        { n: "02", t: "Wallet = ID", d: "No phone, no KYC, no chairman" },
                        { n: "03", t: "Code holds", d: "Auto-rotates payout, trustless" },
                      ].map(s => (
                        <div key={s.n} className="flex gap-3 p-3 rounded-2xl border" style={{ borderColor: "var(--line)", background: "var(--bg-2)" }}>
                          <div className="w-9 h-9 rounded-full flex items-center justify-center font-[800] text-white shrink-0" style={{ background: "linear-gradient(135deg,#FF006A,#FFD60A)" }}>{s.n}</div>
                          <div>
                            <div className="font-[700] text-[14px]">{s.t}</div>
                            <div className="text-[12px] mono" style={{ color: "var(--muted)" }}>{s.d}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="rounded-[28px] border p-5 overflow-hidden relative" style={{ borderColor: "var(--line)", background: "var(--card)" }}>
                    <div className="text-[12px] mono font-bold">NODE NETWORK (no map)</div>
                    <svg viewBox="0 0 200 120" className="mt-4 w-full">
                      <defs>
                        <linearGradient id="nodeGrad" x1="0" x2="1"><stop stopColor="#FF006A"/><stop offset="1" stopColor="#FFD60A"/></linearGradient>
                      </defs>
                      {[
                        [40, 30], [100, 20], [160, 35], [70, 70], [130, 80], [100, 100]
                      ].map((p, i) => (
                        <g key={i}>
                          <circle cx={p[0]} cy={p[1]} r="14" fill="var(--card-2)" stroke="url(#nodeGrad)" strokeWidth="1.5" />
                          <circle cx={p[0]} cy={p[1]} r="4" fill="url(#nodeGrad)" />
                        </g>
                      ))}
                      <path d="M40 30 L100 20 L160 35 L130 80 L70 70 L40 30 M100 20 L70 70 L100 100 L130 80" stroke="#FF006A" strokeOpacity="0.35" strokeWidth="1" fill="none" strokeDasharray="4 6" />
                    </svg>
                    <div className="text-[11px] mono mt-2" style={{ color: "var(--muted)" }}>Peer-to-peer trust graph, not geo dots.</div>
                  </div>
                </div>
              </section>
            )}

            {liveTab === "signup" && (
              <section className="grid md:grid-cols-[0.9fr_1.1fr] gap-5 max-w-[900px] mx-auto">
                <div className="rounded-[28px] border p-6" style={{ borderColor: "var(--line)", background: "var(--card)" }}>
                  <h2 className="text-[28px] font-[800] tracking-[-0.02em] leading-none">Wallet-only.</h2>
                  <p className="mt-2 text-[13px] mono" style={{ color: "var(--muted)" }}>No phone. No KYC. Your wallet is your ID.</p>

                  <div className="mt-6 grid gap-3">
                    <button
                      onClick={() => setWallet("0x7F3c...A9D2")}
                      className="h-12 rounded-full border flex items-center justify-between px-4 font-bold"
                      style={{ borderColor: wallet ? "#00E676" : "var(--line)", background: wallet ? "rgba(0,230,118,0.12)" : "var(--bg-2)" }}
                    >
                      <span className="flex items-center gap-2"><span className="w-6 h-6 rounded-full bg-[#FF8A00] flex items-center justify-center text-[10px]">🦊</span> MetaMask</span>
                      <span className="text-[12px] mono">{wallet ? "Connected ✓" : "Connect"}</span>
                    </button>
                    <button
                      onClick={() => setWallet("0x7F3c...A9D2")}
                      className="h-12 rounded-full border flex items-center justify-between px-4 font-bold"
                      style={{ borderColor: "var(--line)", background: "var(--bg-2)" }}
                    >
                      <span className="flex items-center gap-2"><span className="w-6 h-6 rounded-full bg-[#3B99FC] text-white flex items-center justify-center">W</span> WalletConnect</span>
                      <span className="text-[12px] mono">Connect</span>
                    </button>
                  </div>

                  {wallet && (
                    <div className="mt-4 p-3 rounded-2xl mono text-[12px] border flex items-center justify-between" style={{ borderColor: "var(--line)", background: "var(--card-2)" }}>
                      <span>Mock wallet:</span>
                      <span className="px-2 py-1 rounded-full bg-black text-white font-bold">0x7F...A9D2</span>
                    </div>
                  )}

                  <div className="mt-6">
                    <div className="text-[12px] mono font-bold">POOL SIZE</div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {["₦50k", "₦100k", "₦250k", "₦500k"].map(c => (
                        <button
                          key={c}
                          onClick={() => setChip(c)}
                          className="h-9 px-4 rounded-full border text-[13px] font-[800]"
                          style={{
                            background: chip === c ? "linear-gradient(135deg,#FF006A,#FFD60A)" : "var(--bg-2)",
                            color: chip === c ? "white" : "var(--fg)",
                            borderColor: chip === c ? "transparent" : "var(--line)",
                          }}
                        >
                          {c}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      if (!wallet) setWallet("0x7F3c...A9D2");
                      setLiveTab("dashboard");
                    }}
                    className="mt-8 w-full h-12 rounded-full text-white font-[800] shadow-lg"
                    style={{ background: "linear-gradient(135deg,#FF006A 0%,#FF7A00 60%,#FFD60A 100%)" }}
                  >
                    Create Vault →
                  </button>
                  <div className="mt-3 text-[11px] mono text-center" style={{ color: "var(--muted)" }}>Deploying to Base Sepolia • Gas ~ $0.02</div>
                </div>

                <div className="rounded-[28px] border p-6 relative overflow-hidden" style={{ borderColor: "var(--line)", background: "var(--card-2)" }}>
                  <div className="text-[12px] mono font-bold flex items-center justify-between">
                    <span>VAULT PREVIEW</span>
                    <span className="px-2 py-1 rounded-full text-[10px] border" style={{ borderColor: "var(--line)", background: "var(--card)" }}>Base Sepolia</span>
                  </div>
                  <div className="mt-6 mx-auto w-[200px] h-[200px] rounded-full border-[14px] flex items-center justify-center relative" style={{ borderColor: "var(--line)", background: "var(--card)" }}>
                    <div className="absolute inset-0 rounded-full" style={{ background: "conic-gradient(from 0deg,#FF006A 0% 60%,#EEE 60% 100%)", WebkitMask: "radial-gradient(farthest-side,#0000 calc(100% - 14px),#000 calc(100% - 14px))" }} />
                    <div className="text-center">
                      <div className="text-[11px] mono" style={{ color: "var(--muted)" }}>SELECTED</div>
                      <div className="text-[32px] font-[800]">{chip}</div>
                      <div className="text-[11px] mono">x 5 members</div>
                    </div>
                  </div>
                  <div className="mt-6 grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-2xl border" style={{ borderColor: "var(--line)", background: "var(--card)" }}>
                      <div className="text-[10px] mono" style={{ color: "var(--muted)" }}>CODE HOLDS</div>
                      <div className="text-[13px] font-bold">Non-custodial</div>
                    </div>
                    <div className="p-3 rounded-2xl border" style={{ borderColor: "var(--line)", background: "var(--card)" }}>
                      <div className="text-[10px] mono" style={{ color: "var(--muted)" }}>AUTO-ROTATE</div>
                      <div className="text-[13px] font-bold">Trustless payout</div>
                    </div>
                  </div>
                </div>
              </section>
            )}

            {liveTab === "dashboard" && (
              <section className="grid lg:grid-cols-[1.2fr_0.8fr] gap-5">
                <div className="space-y-5">
                  <div className="rounded-[28px] border p-5 sm:p-6 flex flex-wrap items-center justify-between gap-3" style={{ borderColor: "var(--line)", background: "var(--card)", boxShadow: "var(--shadow)" }}>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full flex items-center justify-center font-[800] text-white" style={{ background: "linear-gradient(135deg,#FF006A,#FFD60A)" }}>#12</div>
                      <div>
                        <div className="font-[800] text-[18px] leading-none">Pool #12 • {chip} • 5 members</div>
                        <div className="mt-1 flex items-center gap-2">
                          <span className="px-2 py-1 rounded-full mono text-[10px] border" style={{ borderColor: "var(--line)", background: "var(--card-2)" }}>Base Sepolia</span>
                          <span className="text-[11px] mono" style={{ color: "var(--muted)" }}>Creator 0x7F...A9D2 • You</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex -space-x-2">
                        {["#FF006A", "#FFD60A", "#C6FF00", "#6A5CFF", "#00E5FF"].map((c, i) => (
                          <div key={i} className="w-8 h-8 rounded-full border-2 flex items-center justify-center text-[10px] font-bold" style={{ background: c, borderColor: "var(--card)" }}>{i === 0 ? "You" : ""}</div>
                        ))}
                      </div>
                      <div className="text-[11px] mono px-2 py-1 rounded-full border" style={{ borderColor: "var(--line)", background: "var(--card-2)" }}>3/5 paid</div>
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-[220px_1fr] gap-5">
                    <div className="rounded-[28px] border p-6 flex flex-col items-center justify-center" style={{ borderColor: "var(--line)", background: "var(--card)" }}>
                      <div className="relative w-[150px] h-[150px]">
                        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                          <circle cx="50" cy="50" r="42" fill="none" stroke="var(--line)" strokeWidth="12" />
                          <circle cx="50" cy="50" r="42" fill="none" stroke="url(#progGrad)" strokeWidth="12" strokeLinecap="round" strokeDasharray={`${60 * 2.64} 264`} />
                          <defs>
                            <linearGradient id="progGrad" x1="0" x2="1"><stop stopColor="#FF006A"/><stop offset="1" stopColor="#FFD60A"/></linearGradient>
                          </defs>
                        </svg>
                        <div className="absolute inset-0 flex flex-col items-center justify-center">
                          <div className="text-[34px] font-[800] leading-none">60%</div>
                          <div className="text-[10px] mono" style={{ color: "var(--muted)" }}>3 / 5 PAID</div>
                        </div>
                      </div>
                      <div className="mt-4 text-center">
                        <div className="text-[11px] mono" style={{ color: "var(--muted)" }}>NEXT PAYOUT IN</div>
                        <div className="mt-1 font-[800] mono text-[16px]">{countdown.d}d {String(countdown.h).padStart(2, "0")}h {String(countdown.m).padStart(2, "0")}m {String(countdown.s).padStart(2, "0")}s</div>
                      </div>
                      <button
                        onClick={() => setPaid(!paid)}
                        className={`mt-5 w-full h-11 rounded-full font-[800] text-[14px] transition-all ${paid ? "border" : "text-white"}`}
                        style={{
                          background: paid ? "var(--card-2)" : "linear-gradient(135deg,#FF006A,#FF7A00)",
                          borderColor: "var(--line)",
                          color: paid ? "var(--fg)" : "white",
                        }}
                      >
                        {paid ? "✓ Paid • On-chain" : "Contribute ₦100k"}
                      </button>
                      <div className="mt-2 text-[10px] mono text-center" style={{ color: "var(--muted)" }}>{paid ? "Tx: 0x9a...f3d1 confirmed" : "Will trigger auto-rotation when 5/5"}</div>
                    </div>

                    <div className="rounded-[28px] border p-5" style={{ borderColor: "var(--line)", background: "var(--card)" }}>
                      <div className="flex items-center justify-between">
                        <div className="text-[12px] mono font-bold">ACTIVITY PULSE</div>
                        <div className="text-[10px] mono px-2 py-1 rounded-full bg-[#00E676]/15 text-[#00A651]">LIVE</div>
                      </div>
                      <div className="mt-4 h-[84px] flex items-end gap-[4px]">
                        {[22, 45, 30, 65, 40, 88, 55, 70, 35, 80, 60, 90, 45].map((h, i) => (
                          <div key={i} className="flex-1 rounded-full" style={{ height: `${h}%`, background: i % 2 === 0 ? "#FF006A" : "#FFD60A", opacity: i > 9 ? 1 : 0.65 }} />
                        ))}
                      </div>
                      <div className="mt-5">
                        <div className="text-[12px] mono font-bold">RECENT ACTIVITY</div>
                        <div className="mt-3 grid gap-2.5">
                          {[
                            { u: "0xA1...3f", a: "Contributed ₦100k", t: "2m ago", c: "#FF006A" },
                            { u: "0xB7...9c", a: "Joined pool", t: "12m ago", c: "#FFD60A" },
                            { u: "You", a: paid ? "Contributed ₦100k" : "Awaiting contribution", t: "now", c: "#C6FF00" },
                            { u: "0xC2...11", a: "Payout ₦500k → 0xA1", t: "1d ago", c: "#6A5CFF" },
                          ].map((r, i) => (
                            <div key={i} className="flex items-center justify-between p-2.5 rounded-xl border" style={{ borderColor: "var(--line)", background: "var(--card-2)" }}>
                              <div className="flex items-center gap-2">
                                <div className="w-7 h-7 rounded-full" style={{ background: r.c }} />
                                <div>
                                  <div className="text-[12px] font-bold leading-none">{r.u} • {r.a}</div>
                                  <div className="text-[10px] mono" style={{ color: "var(--muted)" }}>{r.t}</div>
                                </div>
                              </div>
                              <div className="w-2 h-2 rounded-full bg-[#00E676]" />
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-5">
                  <div className="rounded-[28px] border p-5" style={{ borderColor: "var(--line)", background: "var(--card)" }}>
                    <div className="text-[12px] mono font-bold">NODE NETWORK</div>
                    <svg viewBox="0 0 260 160" className="mt-3 w-full">
                      <defs><linearGradient id="n2" x1="0" x2="1"><stop stopColor="#FF006A"/><stop offset="1" stopColor="#FFD60A"/></linearGradient></defs>
                      {[[40,40],[120,25],[200,45],[70,90],[150,100],[200,120],[30,120]].map((p,i)=>(
                        <g key={i}>
                          <line x1={p[0]} y1={p[1]} x2={120} y2={60} stroke="var(--line)" strokeWidth="1" strokeDasharray="3 4"/>
                          <circle cx={p[0]} cy={p[1]} r="18" fill="var(--card-2)" stroke="url(#n2)" strokeWidth="1.2"/>
                          <circle cx={p[0]} cy={p[1]} r="5" fill={i===0?"#FF006A":"#FFD60A"}/>
                        </g>
                      ))}
                      <circle cx="120" cy="60" r="22" fill="none" stroke="#FF006A" strokeWidth="2" strokeDasharray="6 6"/>
                    </svg>
                    <div className="mt-2 text-[11px] mono" style={{ color: "var(--muted)" }}>Wallet = ID mesh. No central chairman node.</div>
                  </div>

                  <div className="rounded-[28px] border p-5" style={{ borderColor: "var(--line)", background: theme === "dark" ? "#FF006A" : "#FF006A", color: "white" }}>
                    <div className="flex items-center justify-between">
                      <div className="text-[12px] mono font-bold opacity-90">CONTRACT • BASE SEPOLIA</div>
                      <div className="px-2 py-1 rounded-full bg-white text-black text-[10px] mono font-bold">Verified</div>
                    </div>
                    <div className="mt-3 text-[13px] mono break-all leading-tight">0xAjoChain...BaseSepolia: createPool() / contribute() / payout()</div>
                    <div className="mt-3 h-2 rounded-full bg-white/20 overflow-hidden"><div className="h-full w-[87%] bg-white"/></div>
                    <div className="mt-3 flex gap-2">
                      <div className="px-3 py-1.5 rounded-full bg-black/20 mono text-[11px]">₦12.4M TVL</div>
                      <div className="px-3 py-1.5 rounded-full bg-white text-black mono text-[11px] font-bold">©2026 Abuja NG</div>
                    </div>
                  </div>
                </div>
              </section>
            )}
          </div>
        )}

        {tab === "repo" && (
          <section className="grid md:grid-cols-[280px_1fr] gap-4">
            <div className="rounded-[24px] border p-3" style={{ borderColor: "var(--line)", background: "var(--card)" }}>
              <div className="px-3 py-2 text-[12px] mono font-bold flex items-center justify-between">
                <span>FILES • 8</span>
                <span className="px-2 py-1 rounded-full text-[10px]" style={{ background: "var(--card-2)", border: "1px solid var(--line)" }}>fra1::no-404</span>
              </div>
              <div className="mt-2 grid gap-1">
                {repoFiles.map(f => (
                  <button
                    key={f.name}
                    onClick={() => setRepoFile(f.name)}
                    className={`text-left px-3 py-2.5 rounded-xl border text-[13px] mono flex items-center justify-between ${repoFile === f.name ? "font-bold" : ""}`}
                    style={{
                      background: repoFile === f.name ? "linear-gradient(135deg,#FF006A22,#FFD60A22)" : "var(--bg-2)",
                      borderColor: repoFile === f.name ? "#FF006A" : "var(--line)",
                    }}
                  >
                    <span className="truncate">{f.name}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full ml-2" style={{ background: "var(--card-2)" }}>{f.lang}</span>
                  </button>
                ))}
              </div>
              <div className="mt-4 p-3 rounded-xl border text-[11px] mono" style={{ borderColor: "var(--line)", background: "var(--card-2)", color: "var(--muted)" }}>
                Click file → view full code. No external fetch. Self-contained.
              </div>
            </div>

            <div className="rounded-[24px] border overflow-hidden" style={{ borderColor: "var(--line)", background: "#0F0A14" }}>
              <div className="h-10 px-4 flex items-center justify-between border-b border-white/10">
                <div className="text-[12px] mono text-white/80">{activeRepo.name}</div>
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#FF5F56]" />
                  <span className="w-2.5 h-2.5 rounded-full bg-[#FFBD2E]" />
                  <span className="w-2.5 h-2.5 rounded-full bg-[#27C93F]" />
                </div>
              </div>
              <pre className="p-4 sm:p-5 text-[11px] sm:text-[12px] leading-[1.6] mono text-[#E6E0F0] overflow-auto max-h-[560px] whitespace-pre-wrap break-words">
                {activeRepo.content}
              </pre>
            </div>
          </section>
        )}

        {tab === "readme" && (
          <section className="max-w-[860px] mx-auto grid gap-5">
            <div className="rounded-[28px] border p-6 sm:p-8" style={{ borderColor: "var(--line)", background: "var(--card)", boxShadow: "var(--shadow)" }}>
              <div className="flex items-center gap-3">
                <KoloLogoSVG size={48} />
                <div>
                  <h2 className="text-[28px] font-[800] leading-none">AjoChain README</h2>
                  <div className="text-[11px] mono mt-1" style={{ color: "var(--muted)" }}>Decentralized Esusu • Base Sepolia • Wallet = ID</div>
                </div>
              </div>

              <div className="mt-6 grid md:grid-cols-2 gap-6">
                <div>
                  <div className="text-[12px] mono font-bold">SHORT DESCRIPTION (locked)</div>
                  <div className="mt-2 p-4 rounded-2xl border text-[14px] leading-6" style={{ borderColor: "#FF006A", background: "linear-gradient(135deg,#FF006A0D,#FFD60A0D)" }}>
                    Decentralized Esusu. No chairman. Code holds the money, auto-rotates payouts. Base Sepolia.<br />
                    <span className="font-bold">Wallet = ID, no phone, no KYC</span>
                  </div>

                  <div className="mt-6">
                    <div className="text-[12px] mono font-bold">STACK</div>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {["Next.js 14", "Solidity 0.8.20", "Wagmi v2", "RainbowKit", "Base Sepolia", "Viem"].map(s => (
                        <span key={s} className="px-3 py-1.5 rounded-full border text-[11px] mono font-bold" style={{ borderColor: "var(--line)", background: "var(--card-2)" }}>{s}</span>
                      ))}
                    </div>
                  </div>

                  <div className="mt-6">
                    <div className="text-[12px] mono font-bold">BRAND</div>
                    <div className="mt-2 text-[13px] leading-6" style={{ color: "var(--muted)" }}>
                      Vibrant Gen Z • Kolo pot SVG • Magenta <span className="px-2 py-0.5 rounded-full text-white font-bold" style={{ background: "#FF006A" }}>#FF006A</span> → Yellow <span className="px-2 py-0.5 rounded-full text-black font-bold" style={{ background: "#FFD60A" }}>#FFD60A</span> gradient with gold chain. Dark/light toggle per tab.
                    </div>
                  </div>
                </div>

                <div>
                  <div className="text-[12px] mono font-bold">DEPLOY • NO 404</div>
                  <div className="mt-2 grid gap-2">
                    {[
                      "Vercel: vercel --prod",
                      "Netlify: netlify deploy",
                      "Cloudflare Pages: wrangler pages publish",
                      "Fleek / IPFS: fleek sites deploy",
                    ].map(d => (
                      <div key={d} className="p-3 rounded-xl border mono text-[12px] flex items-center gap-2" style={{ borderColor: "var(--line)", background: "var(--bg-2)" }}>
                        <span className="w-2 h-2 rounded-full bg-[#00E676]" /> {d}
                      </div>
                    ))}
                  </div>

                  <div className="mt-6">
                    <div className="text-[12px] mono font-bold">INSTALL & RUN</div>
                    <pre className="mt-2 p-4 rounded-xl border mono text-[12px] leading-6 overflow-auto" style={{ borderColor: "var(--line)", background: "#0F0A14", color: "#E6E0F0" }}>
{`npm install
# no red screen fix
rm -rf .next && npm run dev

# wallet-only auth
# lib/wagmi.ts uses Base Sepolia
# contracts/AjoChain.sol

# single-file export for this artifact
# ajochain_final_clean.html -> open, no 404`}
                    </pre>
                  </div>

                  <div className="mt-6 p-3 rounded-xl border text-[11px] mono" style={{ borderColor: "var(--line)", background: "var(--card-2)" }}>
                    Auth: wallet-only, no phone, MetaMask + WalletConnect, mock 0x7F...A9D2 • Fixed fra1::2btdr-1793719950947-27541e4e64fd
                  </div>
                </div>
              </div>

              <div className="mt-8 flex items-center justify-between border-t pt-4" style={{ borderColor: "var(--line)" }}>
                <div className="text-[11px] mono" style={{ color: "var(--muted)" }}>©2026 Abuja NG • The bank is the code.</div>
                <div className="px-3 py-1 rounded-full bg-[var(--fg)] text-[var(--bg)] mono text-[11px] font-bold">SELF-CONTAINED • 1 HTML</div>
              </div>
            </div>
          </section>
        )}
      </main>

      {/* Bottom nav for Live App only */}
      {tab === "live" && (
        <nav
          className="fixed bottom-0 inset-x-0 z-30 border-t md:hidden"
          style={{ background: theme === "dark" ? "rgba(15,10,20,0.92)" : "rgba(255,248,240,0.92)", borderColor: "var(--line)", backdropFilter: "blur(16px)" }}
        >
          <div className="mx-auto max-w-[1080px] px-2 h-[72px] grid grid-cols-3 gap-2">
            {[
              { k: "landing", label: "Landing", icon: "◉" },
              { k: "signup", label: "Sign Up", icon: "◎" },
              { k: "dashboard", label: "Dashboard", icon: "◍" },
            ].map(i => (
              <button
                key={i.k}
                onClick={() => setLiveTab(i.k as LiveTab)}
                className="rounded-2xl flex flex-col items-center justify-center gap-1"
                style={{
                  background: liveTab === i.k ? "linear-gradient(135deg,#FF006A,#FFD60A)" : "transparent",
                  color: liveTab === i.k ? "white" : "var(--muted)",
                }}
              >
                <span className="text-[16px]">{i.icon}</span>
                <span className="text-[11px] mono font-bold">{i.label}</span>
              </button>
            ))}
          </div>
        </nav>
      )}

      {/* Desktop live sub nav when live */}
      {tab === "live" && (
        <div className="hidden md:flex fixed bottom-6 left-1/2 -translate-x-1/2 z-30 p-1.5 rounded-full border shadow-xl" style={{ background: "var(--card)", borderColor: "var(--line)" }}>
          {[
            { k: "landing", label: "Landing" },
            { k: "signup", label: "Sign Up" },
            { k: "dashboard", label: "Dashboard" },
          ].map(b => (
            <button
              key={b.k}
              onClick={() => setLiveTab(b.k as LiveTab)}
              className="h-9 px-5 rounded-full text-[13px] font-[700]"
              style={{
                background: liveTab === b.k ? "var(--fg)" : "transparent",
                color: liveTab === b.k ? "var(--bg)" : "var(--muted)",
              }}
            >
              {b.label}
            </button>
          ))}
        </div>
      )}

      <footer className="mx-auto max-w-[1080px] px-6 pb-10 pt-2 hidden md:flex items-center justify-between text-[11px] mono" style={{ color: "var(--muted)" }}>
        <span>©2026 Abuja NG • AjoChain • Base Sepolia • No map dots • Self-contained artifact</span>
        <span className="px-3 py-1 rounded-full border" style={{ borderColor: "var(--line)", background: "var(--card)" }}>fra1 fix applied • ajochain_final_clean.html</span>
      </footer>
    </div>
  );
}
